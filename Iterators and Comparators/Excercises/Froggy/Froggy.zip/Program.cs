﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Froggy
{
    public class StartUp
    {
        static void Main()
        {
            Lake lake = new Lake(Console.ReadLine()
                .Split(", ")
                .Select(int.Parse)
                .ToArray());

           
            foreach (int index in lake)
            {
                if (index % 2 == 0)
                {
                    Console.WriteLine(lake.stones[index]);
                }
            }
            lake.stones.Reverse();

            foreach (int index in lake)
            {
                if (index % 2 == 0)
                {
                    Console.WriteLine(lake.stones[index]);
                }
            }
        }
    }
}

