﻿using System;
using System.Collections.Generic;
using System.Text;
using Zoo.Animal;

namespace Zoo
{
    internal class Snake : Reptile
    {
        public Snake(string name) : base(name)
        {
        }
    }
}
